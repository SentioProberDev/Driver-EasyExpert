/* --------------------------------------------------------
   Library Function HeaderFile

   (c) Copyright MPI corporation 2019
   All rights reserved.

   Internal releaes only now
   Versoin: V1.4

   ---------------------------------------------------------*/

#ifndef _B1500_PRBDRV_GPIB_INCLUDE
#define _B1500_PRBDRV_GPIB_INCLUDE

enum GpibLogMode { GPIB_LOG_ON, GPIB_LOG_OFF };

extern int GpibOpen( const char *resource);
extern int GpibClose();
extern int GpibOutput(const char *command );
extern int GpibEnter(char *string);
extern int GpibSrq(int *statusByte);

extern int GpibLogInit();
extern int GpibSetLog(const enum GpibLogMode mode, const char *logfile);


#endif //_B1500_PRBDRV_GPIB_INCLUDE
