/* --------------------------------------------------------
   Library Function HeaderFile

   (c) Copyright MPI corporation 2019
   All rights reserved.

   Internal releaes only now
   Versoin: V1.4

   ---------------------------------------------------------*/
#ifndef _B1500_PRBDRV_LIB_INCLUDE
#define _B1500_PRBDRV_LIB_INCLUDE

extern char getopt(int argc, char * const argv[], const char *optString, char *optarg);
extern char *chomp( char *string );
extern char *strtrim( char *string );

extern int FileExists( const char *path );
extern int FileCopy( const char *src, const char *dest );
extern int FileDelete( const char *target );

extern int DirectoryCreate( const char *path );

extern void PathCompose( char *dest, const char *lpath, const char *rpath );
extern int  PathChangeExtension( char *path, const char *ext );

extern void GetExecutableDirectory( char *path );
extern void GetAppDataDirectory( char *path );
extern void GetCommonAppDataDirectory( char *path );

#endif  // _B1500_PRBDRV_LIB_INCLUDE
