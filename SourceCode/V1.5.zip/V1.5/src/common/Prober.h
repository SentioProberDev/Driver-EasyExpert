/* --------------------------------------------------------
   Prober Function HeaderFile

   (c) Copyright MPI corporation 2019
   All rights reserved.

   Internal releaes only now
   Versoin: V1.4

   ---------------------------------------------------------*/

#ifndef _B1500_PRBDRV_PROBER_INCLUDE
#define _B1500_PRBDRV_PROBER_INCLUDE

#include "Utility.h"

#define  TARGET_MAXLEN        (1024)
#define  SUBSITE_MAXLEN       (1024)

// proto type
extern int ProberConnect( const proberinfo *pinfo);
extern int ProberDisConnect();
extern int ProberInitial();
extern int ProberStageUp();
extern int ProberStageDown();
extern int ProberMoveToNextDie(int *WaferEnd, int *WaferStop );
extern int ProberMoveToNextSubsite(int *DieEnd);
extern int ProberGetDiePosition(char *targt, const setupinfo *setup );
extern int ProberGetSubsitePosition(char *subsite);
extern int ProberGetTotalSubsiteCount(int *SubsiteCount);
extern int ProberGetCurrSubsiteIndex (int *SubsiteIndex);
extern int ProberGetWaferInfo( variableinfo *vinfo);
extern int ProberGetSubsiteStatus(int *index, int *SubsiteStatus);

#endif //_B1500_PRBDRV_PROBER_INCLUDE

