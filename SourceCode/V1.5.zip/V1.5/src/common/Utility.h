/* --------------------------------------------------------
   Library Function HeaderFile

   (c) Copyright MPI corporation 2019
   All rights reserved.

   Internal releaes only now
   Versoin: V1.4

   ---------------------------------------------------------*/
#ifndef _B1500_PRBDRV_UTILITY_INCLUDE
#define _B1500_PRBDRV_UTILITY_INCLUDE

#define  RESPONSE_TRUE     "True"
#define  RESPONSE_FALSE    "False"

#define  ON                   (1)
#define  OFF                  (0)

#define  ADDRESS_MAXLEN       (64)
#define  LOG_PATH_MAXLEN      (256)

#define  DEVICEID_MAXLEN      (512)

#define  WAFER_SIZE_MAXLEN    (64)
#define  DIE_SIZE_MAXLEN      (64)

typedef struct
{
   struct 
   {
      char address[ADDRESS_MAXLEN];
      int  log_mode;
      char log_file_path[LOG_PATH_MAXLEN];
   } prober;

   struct 
   {
      int use_device_id;
      int use_subsite_info;
      int use_wafer_info;
   } condition;
} proberinfo;

typedef struct 
{
   struct 
   {
      char  id[DEVICEID_MAXLEN];
   } device;

   struct
   {
      char  wafer_size[WAFER_SIZE_MAXLEN];   // Wafer size string
      char  die_size_x[DIE_SIZE_MAXLEN];     // Die size(x) string
      char  die_size_y[DIE_SIZE_MAXLEN];     // Die size(y) string
   } wafer;
} variableinfo; 

typedef struct
{
   proberinfo    pinfo;
   variableinfo  vinfo;
} setupinfo;


extern int  ParseOpt( int argc, char *argv[], proberinfo *pinfo );
extern int  ParseIni( setupinfo *setup );
extern int  WriteVariables( const variableinfo *vinfo );
extern void ShowErrorMessage( const char *printFmt, ... );
extern int  WriteResponse( const char *breakflag, 
                           const char *target, 
                           const char *subsite, 
                           const setupinfo *setup );

#endif  // _B1500_PRBDRV_UTILITY_INCLUDE
