/* --------------------------------------------------------
   Framework (main) Source

   consitute a final procedure.

   (c) Copyright Agilent Technologies 2005, 2008
   All rights reserved.


   Customer shall have the personal, non-
   transferable right to use, copy or modify
   this SAMPLE PROGRAM for Customer's internal
   operations.  Customer shall use the SAMPLE
   PROGRAM solely and exclusively for its own
   purpose and shall not license, lease, market
   or distribute the SAMPLE PROGRAM or modification
   or any part thereof.

   Agilent shall not be liable for the quality,
   performance or behavior of the SAMPLE PROGRAM.
   Agilent especially disclaims that the operation
   of the SAMPLE PROGRAM shall be uninterrupted or
   error free.  This SAMPLE PROGRAM is provided
   AS IS.

   AGILENT DISCLAIMS THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR
   PURPOSE.

   Agilent shall not be liable for any infringement
   of any patent, trademark copyright or other
   proprietary rights by the SAMPLE PROGRAM or
   its use. Agilent does not warrant that the SAMPLE
   PROGRAM is free from infringements or such
   right of third parties. However, Agilent will not
   knowingly infringe or deliver a software that
   infringes the patent, trademark, copyright or
   other proprietary right of a third party.

   Version     :  A.03.20

   ---------------------------------------------------------*/

#include "resource.h"        // resource(dialog)

#include "Utility.h"         // Utility Function
#include "Prober.h"          // Prober Function

#define  APP_TARGET  "Filnal_mpi.exe"

// proto type
static void ShowUsage();

/*------------------------------------------------
  Function :  main
  Descript :  Console Application Main
  Input    :  argc  : number of arguments
  argv  : string of arguments      
  Output      :     
  Return      :  0:Success 1:Error has Occurred   
  ------------------------------------------------*/
int main(int argc, char *argv[])
{
   setupinfo setup;

   if (ParseIni( &setup ) != 1)            // parse(read) ini file
   {
      return 1;                                       // error has occurred
   }

   if (ParseOpt(argc, argv, &(setup.pinfo) ) != 1)   // parse option(argv)
   {
      ShowUsage();                     // error has occurred
      return 1;
   }

   if (ProberConnect( &(setup.pinfo) ) != 1)        // Connect to Prober(GPIB open)
   {
      return 1;                        // error has occurred
   }

   if (ProberStageDown() != 1)           // stage down (separate from pin)
   {
      ProberDisConnect();                // error has occurred
      return 1;
   }

   if (ProberDisConnect() != 1)        // DisConnect to Prober(GPIB close)
   {
      return 1;                        // error has occurred
   }
   // all procedures pass !
   return 0;
}




/*------------------------------------------------
  Function :  ShowUsage
  Descript :  show usage. 
  Input    :     
  Output      :     
  Return      :  
  ------------------------------------------------*/
void ShowUsage()
{
   ShowErrorMessage("%s%s%s%s%s%s%s%s",
                    "usage : ", APP_TARGET, " [-a resource] [-l logfilename(full path)] \r\n",
                    "\t -a : designate GPIB address \r\n",
                    "\t -l : log mode on \r\n",
                    "\t ex) ", APP_TARGET, " -a GPIB0::5::INSTR -l C:\\prober.log\t\r\n");
}
