/* --------------------------------------------------------
   Framework (main) Source

   consitute a startup procedure.

   (c) Copyright Agilent Technologies 2005, 2008
   All rights reserved.


   Customer shall have the personal, non-
   transferable right to use, copy or modify
   this SAMPLE PROGRAM for Customer's internal
   operations.  Customer shall use the SAMPLE
   PROGRAM solely and exclusively for its own
   purpose and shall not license, lease, market
   or distribute the SAMPLE PROGRAM or modification
   or any part thereof.

   Agilent shall not be liable for the quality,
   performance or behavior of the SAMPLE PROGRAM.
   Agilent especially disclaims that the operation
   of the SAMPLE PROGRAM shall be uninterrupted or
   error free.  This SAMPLE PROGRAM is provided
   AS IS.

   AGILENT DISCLAIMS THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR
   PURPOSE.

   Agilent shall not be liable for any infringement
   of any patent, trademark copyright or other
   proprietary rights by the SAMPLE PROGRAM or
   its use. Agilent does not warrant that the SAMPLE
   PROGRAM is free from infringements or such
   right of third parties. However, Agilent will not
   knowingly infringe or deliver a software that
   infringes the patent, trademark, copyright or
   other proprietary right of a third party.

   Version     :  A.03.20

   ---------------------------------------------------------*/

#include "resource.h"        // resource(dialog)

#include "Utility.h"         // Utility Function
#include "Prober.h"  // Prober Function

#include <stdio.h>
#include <windows.h>

#define  APP_TARGET  "Start_mpi.exe"

// define for dialog.
#define  PROBER_WAIT_MESSAGE     "Load and align wafer then click OK."
#define  PROBER_WAIT_CAPTION     "Start Confirmation"

#define DIALOGINPUT_MAXLEN (256)
static char dialogInput[DIALOGINPUT_MAXLEN];

#define WAFERINFO_INPUT_REQUIRED (1)

// ProtoType 

static void ShowUsage();
static LRESULT CALLBACK _my_dlg_prc(HWND hDlgWnd, UINT msg, WPARAM wp, LPARAM lp);

/*------------------------------------------------
  Function  :  main
  Descript  :  Console Application Main
  Input     :  argc  : number of arguments
  argv   : string of arguments      
  Output    :     
  Return    :  0:Success 1:Error has Occurred   
  ------------------------------------------------*/
int main(int argc, char *argv[])
{
   char  target[TARGET_MAXLEN]   = {'\0'};
   char  subsite[SUBSITE_MAXLEN] = {'\0'};
   setupinfo setup;




//----TEST--------------only--------



   char buffer[100];
      char  *p;
   char  *pos;
int test;
char *arr[3];
const char *del = ",";

char *buff = "0,0,11,22";
   char subbuff[5];
      buffer[0]='0';
buffer[1]=',';
buffer[2]='0';
buffer[3]=',';
   buffer[4]='33';
buffer[5]=',';
buffer[6]='44';


   pos = (char *)strchr(buff, ',');

memcpy( subbuff, &buff[3], 2 );
subbuff[5] = '\0';





     //split(arr, buffer, del);

while(test<3)
printf("%s\n", *(arr+test++));

	//for(test = 0; test<10; test++)
	//{
	//	pos = (char *)strchr(buffer, ',');     // get ',' position
	//	printf ("found at %d\n",pos-buffer+1);
	//}










   if (ParseIni(&setup) != 1)                        // parse(read) ini file
   {
      WriteResponse(RESPONSE_TRUE, target, subsite, &setup);      // error has occurred
      return 1;
   }

   if (ParseOpt(argc, argv, &(setup.pinfo)) != 1)               // parse option(argv)
   {
      ShowUsage();                                             // error has occurred
      WriteResponse(RESPONSE_TRUE, target, subsite, &setup);
      return 1;
   }

   if (ProberConnect( &(setup.pinfo) ) != 1)                            // Connect to Prober(GPIB open)
   {
      WriteResponse(RESPONSE_TRUE, target, subsite, &setup);      // error has occurred
      return 1;
   }

   if ( setup.pinfo.condition.use_device_id == ON )        // use ID?
   {
      // show Device ID input dialog
      int result = (int)DialogBox(NULL, MAKEINTRESOURCE(IDD_INPUTID1), 
                                  NULL, (DLGPROC)_my_dlg_prc);    
      
      if (result != IDOK)             // when the cancel button is pushed
      {
         WriteResponse(RESPONSE_TRUE, target, subsite, &setup);
         ProberDisConnect();
         return 1;
      }
      strncpy( setup.vinfo.device.id, dialogInput, DEVICEID_MAXLEN );

      if (WriteVariables( &(setup.vinfo )) != 1)
      {
         WriteResponse(RESPONSE_TRUE, target, subsite, &setup);
         ProberDisConnect();
         return 1;
      }
   }

   if ( setup.pinfo.condition.use_wafer_info == ON && WAFERINFO_INPUT_REQUIRED )
   {           
      char  *p;
      long  l;
   
      // Get waferinfo?
      int result = (int)DialogBox(NULL, MAKEINTRESOURCE(IDD_INPUTID2), 
                                  NULL, (DLGPROC)_my_dlg_prc);     // show input dialog

      if (result != IDOK)                      // when the cancel button is pushed
      {
         WriteResponse(RESPONSE_TRUE, target, subsite, &setup);
         ProberDisConnect();
         return 1;
      }
      
      p = (char *)strtok(dialogInput, ",");
      if (p == NULL || sscanf(p, "%ld", &l) != 1){
         ShowErrorMessage("Error has occurred. Wrong parameter WaferSize: \"%s\"\r\n", p);
         setup.vinfo.wafer.wafer_size[0]='\0';
         WriteResponse(RESPONSE_TRUE, target, subsite, &setup);
         ProberDisConnect();
         return 1;
      }
      sprintf(setup.vinfo.wafer.wafer_size, "%ld", l);

      p = (char *)strtok(NULL, ",");
      if (p == NULL || sscanf(p, "%ld", &l) != 1){ 
         ShowErrorMessage("Error has occurred. Wrong parameter DieStepX: \"%s\"\r\n", p);
         setup.vinfo.wafer.die_size_x[0]='\0';
         WriteResponse(RESPONSE_TRUE, target, subsite, &setup);
         ProberDisConnect();
         return 1;
      }
      sprintf(setup.vinfo.wafer.die_size_x, "%ld", l);

      p = (char *)strtok(NULL, ",");
      if (p == NULL || sscanf(p, "%ld", &l) != 1){ 
         ShowErrorMessage("Error has occurred. Wrong parameter DieStepY: \"%s\"\r\n", p);
         setup.vinfo.wafer.die_size_y[0]='\0';
         WriteResponse(RESPONSE_TRUE, target, subsite, &setup);
         ProberDisConnect();
         return 1;
      }
      sprintf( setup.vinfo.wafer.die_size_y, "%ld", l);

      if (WriteVariables( &(setup.vinfo )) != 1)
      {
         WriteResponse(RESPONSE_TRUE, target, subsite, &setup);
         ProberDisConnect();
         return 1;
      }
   }


   // show dialog and confirm prober setup.
   MessageBox( NULL, PROBER_WAIT_MESSAGE, PROBER_WAIT_CAPTION, 
               MB_ICONINFORMATION | MB_OK | MB_APPLMODAL);

   if (ProberInitial() != 1)                             // move to initial chip
   {
      WriteResponse(RESPONSE_TRUE, target, subsite, &setup);      // error has occurred
      ProberDisConnect();
      return 1;
   }

   if (ProberGetDiePosition(target, &setup) != 1){                     // get current die information
      WriteResponse(RESPONSE_TRUE, target, subsite, &setup);      // error has occurred
      ProberDisConnect();
      return 1;
   }

   if ( setup.pinfo.condition.use_subsite_info == ON ) 
   {
      if (ProberGetSubsitePosition(subsite) != 1)            // get current subsite information
      {   
         WriteResponse(RESPONSE_TRUE, target, subsite, &setup);   // error has occurred
         ProberDisConnect();
         return 1;
      }
   }

   if ( setup.pinfo.condition.use_wafer_info == ON )
   {
      if (ProberGetWaferInfo(&(setup.vinfo )) != 1)                // get wafer information
      {
         WriteResponse(RESPONSE_TRUE, target, subsite, &setup);   // error has occurred
         ProberDisConnect();
         return 1;
      }
   }

   if (ProberStageUp() != 1)                            // stage up (connect pin)
   {
      WriteResponse(RESPONSE_TRUE, target, subsite, &setup);      // error has occurred
      ProberDisConnect();
      return 1;
   }

   if (ProberDisConnect() != 1)                           // DisConnect to Prober(GPIB close)
   {
      WriteResponse(RESPONSE_TRUE, target, subsite, &setup);      // error has occurred
      return 1;
   }
   // all procedures pass !
   WriteResponse(RESPONSE_FALSE, target, subsite, &setup);
   return 0;
}




/*------------------------------------------------
  Function  :  ShowUsage
  Descript  :  show usage. 
  Input     :     
  Output    :     
  Return    :  
  ------------------------------------------------*/
void ShowUsage()
{
   ShowErrorMessage("%s%s%s%s%s%s%s%s",
                    "usage : ", APP_TARGET, " [-a resource] [-l logfilename(full path)] \r\n",
                    "\t -a : designate GPIB address \r\n",
                    "\t -l : log mode on \r\n",
                    "\t ex) ", APP_TARGET, " -a GPIB0::13::INSTR -l C:\\prober.log\t\r\n");
}

/*------------------------------------------------
  Function  :  _my_dlg_prc
  Descript  :  call function for performing message processing of an INPUT dialog
  Input     :  auto  
  Output    :     
  Return    :  TRUE/FALSE
  ------------------------------------------------*/
LRESULT CALLBACK _my_dlg_prc(HWND hDlgWnd, UINT msg, WPARAM wp, LPARAM lp)
{
   HWND  hDeskWnd;
   RECT  deskrc, rc;
   int      x, y;

   switch (msg) {
   case WM_INITDIALOG:     // initialize
      SetDlgItemText(hDlgWnd, IDD_INPUTID, (LPCTSTR)"");   
      hDeskWnd = GetDesktopWindow();   // position of window is set up in the center
      GetWindowRect(hDeskWnd, (LPRECT)&deskrc); // get desktop size
      GetWindowRect(hDlgWnd, (LPRECT)&rc);      // get dialog size
      x = (deskrc.right - (rc.right-rc.left)) / 2;
      y = (deskrc.bottom - (rc.bottom-rc.top)) / 2;
      SetWindowPos(hDlgWnd, HWND_TOP, x, y, (rc.right-rc.left), (rc.bottom-rc.top),SWP_SHOWWINDOW); 
      return TRUE;
   case WM_COMMAND:     // push button
      switch (LOWORD(wp)) {
      case IDOK:     // OK button
         // set global variable from input dialog
         GetDlgItemText(hDlgWnd, IDC_EDIT1, (LPTSTR)dialogInput, DIALOGINPUT_MAXLEN);
         EndDialog(hDlgWnd, IDOK);     // close dialog
         break;
      case IDCANCEL: // cancel button
         EndDialog(hDlgWnd, IDCANCEL); // close dialog
         break;
      default:
         return FALSE;
      }
   default:
      return FALSE;
   }
}

