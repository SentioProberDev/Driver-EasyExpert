/* --------------------------------------------------------
   Prober Function

   (c) Copyright Agilent Technologies 2019
   All rights reserved.


   Customer shall have the personal, non-
   transferable right to use, copy or modify
   this SAMPLE PROGRAM for Customer's internal
   operations.  Customer shall use the SAMPLE
   PROGRAM solely and exclusively for its own
   purpose and shall not license, lease, market
   or distribute the SAMPLE PROGRAM or modification
   or any part thereof.

   Agilent shall not be liable for the quality,
   performance or behavior of the SAMPLE PROGRAM.
   Agilent especially disclaims that the operation
   of the SAMPLE PROGRAM shall be uninterrupted or
   error free.  This SAMPLE PROGRAM is provided
   AS IS.

   AGILENT DISCLAIMS THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR
   PURPOSE.

   Agilent shall not be liable for any infringement
   of any patent, trademark copyright or other
   proprietary rights by the SAMPLE PROGRAM or
   its use. Agilent does not warrant that the SAMPLE
   PROGRAM is free from infringements or such
   right of third parties. However, Agilent will not
   knowingly infringe or deliver a software that
   infringes the patent, trademark, copyright or
   other proprietary right of a third party.

   Versoin: V1.3

   ---------------------------------------------------------*/
#include "Prober.h"
#include "GPIB.h"
#include "Lib.h"

#include <stdio.h>
#include <string.h>

#include <windows.h>

#define  PRB_DEVID               (1)
#define  PRB_COMMAND_MAXLEN      (1024)
#define  PRB_ERR_MSG_MAXLEN      (1024)

#define  TARGETID_FORMAT         "%s : %d %d"

#define  DRIVE_WAIT_MILLISEC     (500)
#define  MPI_SEPARATOR          ","
#define  SUSS_SEPARATOR			" "
#define  STB_WAFEREND            (703)
#define  PROBER_WAIT_CAPTION	"Prober Message"

static int _statue_response;
static int _list_index;
static int _die_x;
static int _die_y;
static int _subsite_index;
static int _previous_die_x;
static int _previous_die_y;
static int _totalSubsiteNumber;
static int _curSubsiteIdx;
static int _subsiteStatus;

static int _prober_output_enter(const char *command, int *statusbyte, char *response);
static int _prober_wait_drive_complete();
static void _prober_parse_pos(char *response);
static void _prober_parse_pos_subsite(char *response);
/*------------------------------------------------
  Function :  ProberConnect
  Descript :  Connect to Prober 
  Input    :  pinfo
  Output   :     
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ProberConnect( const proberinfo *pinfo)
{
   if( GpibSetLog( pinfo->prober.log_mode == ON ? GPIB_LOG_ON : GPIB_LOG_OFF,
                   pinfo->prober.log_file_path ) != 1 )
   {
      return 0;
   }

   return GpibOpen(pinfo->prober.address);
}

/*------------------------------------------------
  Function :  ProberDisConnect
  Descript :  DisConnect from Prober  
  Input    :     
  Output   :     
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ProberDisConnect()
{
   return GpibClose();
}

/*------------------------------------------------
  Function :  ProberInitial
  Descript :  move to first & clear log  
  Input    :     
  Output   :     
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ProberInitial()
{
   char  command[PRB_COMMAND_MAXLEN];
   char  response[PRB_COMMAND_MAXLEN];
   int      stb;

   if (GpibLogInit() != 1) return 0;					// Clear GPIB Log

	sprintf(command, "*RCS 1");							// switch SENTIO command
   if (_prober_output_enter_no_response(command) != 1){
      return 1;
   }

   sprintf(command, "map:step_first_die");            // move to first die
   if (_prober_output_enter(command, &stb, response) != 1){
      return 0;
   }

   sprintf(command, "map:die:get_current_index");            // get die index
   if (_prober_output_enter(command, &stb, response) != 1){
      return 0;
   }
   _prober_parse_pos(response);						// parse die position.

   return 1 ;
}

/*------------------------------------------------
  Function :  ProberStageUp
  Descript :  Stage Up (connect to dut)  
  Input    :     
  Output   :     
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ProberStageUp()
{
   char  command[PRB_COMMAND_MAXLEN];
   char  response[PRB_COMMAND_MAXLEN];
   int      stb;

   sprintf(command, "move_chuck_contact");        // stage up
   if (_prober_output_enter(command, &stb, response) != 1){
      return 0;
   }
   return 1;        // wait to complete moving
}

/*------------------------------------------------
  Function :  ProberStageDown
  Descript :  Stage Down (disconnect from dut) 
  Input    :     
  Output   :     
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ProberStageDown()
{
   char  command[PRB_COMMAND_MAXLEN];
   char  response[PRB_COMMAND_MAXLEN];
   int      stb;
   sprintf(command, "move_chuck_separation");     // stage down
   if (_prober_output_enter(command, &stb, response) != 1){
      return 0;
   }
   return 1;        // wait to complete moving
}

/*------------------------------------------------
  Function :  ProberMoveToNextDie
  Descript :  move to next chip 
  Input    :     
  Output   :  WaferEnd : 1:Chip End/0:Not End  
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ProberMoveToNextDie(int *WaferEnd, int *WaferStop)
{
   char  command[PRB_COMMAND_MAXLEN];
   char  response[PRB_COMMAND_MAXLEN];
   int   stb,  stb2;
   int   subsiteStatus;
   int   subsiteNumber;
   int   i;
   char  *p;

   *WaferEnd=0;
	*WaferStop=0;

   sprintf(command, "map:step_next_die");       // move to next die
   if (_prober_output_enter(command, &stb, response) != 1){
      return 0;
   }

   if(stb != 11)								// Not at last die
   {
	   ProberGetTotalSubsiteCount(&subsiteNumber);

	   for(i=0; i < subsiteNumber-1; i++)
	   {
			ProberGetSubsiteStatus(i, &subsiteStatus);
			if(subsiteStatus == 1)
			{
				break;
			}
	   }

	   sprintf(command, "map:subsite:step %d", i);       // move to first subsite
	   if (_prober_output_enter(command, &stb2, response) != 1){
		  return 0;
	   }
   }

   	p = strtok(response, MPI_SEPARATOR);  // result
	p = strtok(NULL, MPI_SEPARATOR);  // id
	p = strtok(NULL, MPI_SEPARATOR);  // list_index(x)
	if (p != NULL) sscanf(p, "%d", &_die_x);  // row(y)
	p = strtok(NULL, MPI_SEPARATOR);      
	if (p != NULL) sscanf(p, "%d", &_die_y); // column(x)
	p = strtok(NULL, MPI_SEPARATOR);     
	if (p != NULL) sscanf(p, "%d", &_subsite_index);

   if (stb == 1024) 
   {
		sprintf(command, "map:die:get_current_index");            // get die index
		if (_prober_output_enter(command, &stb, response) != 1){
			return 0;
		}
		_prober_parse_pos(response);								// parse die position.

      *WaferEnd=1;													// next die does not exists.
      return 1;										// not error( return value is success )            
   }

	if (stb == 11)
	{
	   sprintf(command, "map:die:get_current_index");            // get die index
	   if (_prober_output_enter(command, &stb, response) != 1){
		  return 0;
	   }
	   _prober_parse_pos(response);              // parse die position.

		*WaferStop=1;   // next die does not exists.
		return 1;      // not error( return value is success )            
	}

   sprintf(command, "map:die:get_current_index");            // get die index
   if (_prober_output_enter(command, &stb, response) != 1){
      return 0;
   }
   _prober_parse_pos(response);              // parse die position.
   return 1;        // wait to complete moving
}

/*------------------------------------------------
  Function :  ProberMoveToNextSubsite
  Descript :  move to next subsite 
  Input    :     
  Output   :  DieEnd : 1:subsite End/0:Not End 
  Return   :  1:Success/0:Fail(Error has Occurred)  
  Note	   :  Subsite movement will stop in the same die. it will not auto stepping next die
  ------------------------------------------------*/
int ProberMoveToNextSubsite(int *DieEnd)
{
   char  command[PRB_COMMAND_MAXLEN];
   char  response[PRB_COMMAND_MAXLEN];
   int      stb;
   int subsiteNumber,curSubsiteIndex;
   char  *p;
   *DieEnd=0;

   ProberGetTotalSubsiteCount(&subsiteNumber);
   ProberGetCurrSubsiteIndex(&curSubsiteIndex);

	if (curSubsiteIndex == subsiteNumber-1)
	{
	  *DieEnd = 1;               // next subsite does not exists.
	  return 1;
	}

   sprintf(command, "map:subsite:step_next"); // move to next subsite
   if (_prober_output_enter(command, &stb, response) != 1){
      *DieEnd = 1;               // next subsite does not exists.
      return 1;
   }

	/*
	p = strtok(response, MPI_SEPARATOR);  // result
	p = strtok(NULL, MPI_SEPARATOR);  // id
	p = strtok(NULL, MPI_SEPARATOR);  // list_index(x)
	if (p != NULL) sscanf(p, "%d", &_die_x);  // row(x)
	p = strtok(NULL, MPI_SEPARATOR);      
	if (p != NULL) sscanf(p, "%d", &_die_y); // column(y)
	p = strtok(NULL, MPI_SEPARATOR);     
	if (p != NULL) sscanf(p, "%d", &_subsite_index);
*/

   sprintf(command, "map:die:get_current_index");            // get die index
   if (_prober_output_enter(command, &stb, response) != 1){
      return 0;
   }

   _prober_parse_pos(response);              // parse die position.
   return 1;        // wait to complete moving
}

/*------------------------------------------------
  Function :  ProberGetTotalSubsiteCount
  Descript :  get total subsite number   
  Input    :   
  Output   :  int total subsite number: return int   
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/

int ProberGetTotalSubsiteCount(int *SubsiteCount)
{
   char  command[PRB_COMMAND_MAXLEN];
   char  response[PRB_COMMAND_MAXLEN];
   int      stb;
   char  *p;

   sprintf(command, "map:subsite:get_num"); // move to next subsite
   if (_prober_output_enter(command, &stb, response) != 1){
      return 1;
   }

   	p = strtok(response, MPI_SEPARATOR);  // result
	p = strtok(NULL, MPI_SEPARATOR);  // id
	p = strtok(NULL, MPI_SEPARATOR);  // list_index(x)
	if (p != NULL) sscanf(p, "%d", &_totalSubsiteNumber);  // row(y)

   *SubsiteCount = _totalSubsiteNumber;
   return 1;
}

/*------------------------------------------------
  Function :  ProberGetCurrSubsiteIndex
  Descript :  get Current subsite index   
  Input    :   
  Output   :  int Current subsite idex: return int   
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ProberGetCurrSubsiteIndex(int *SubsiteIndex)
{
   char  command[PRB_COMMAND_MAXLEN];
   char  response[PRB_COMMAND_MAXLEN];
   int      stb;
   char  *p;

   sprintf(command, "map:die:get_current_subsite"); // move to next subsite
   if (_prober_output_enter(command, &stb, response) != 1){
      return 1;
   }

   	p = strtok(response, MPI_SEPARATOR);  // result
	p = strtok(NULL, MPI_SEPARATOR);  // id
	p = strtok(NULL, MPI_SEPARATOR);  // list_index(x)
	if (p != NULL) sscanf(p, "%d", &_curSubsiteIdx);  // row(y)

   *SubsiteIndex = _curSubsiteIdx;
   return 1;
}

/*------------------------------------------------
  Function :  ProberGetDiePosition
  Descript :  get chip position    
  Input    :  setup   
  Output   :  str : return string  
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ProberGetDiePosition(char *str, const setupinfo *setup )
{
   if ( setup->pinfo.condition.use_device_id == ON )      // useID=True   (DeviceID:die position)
   {
      sprintf(str, TARGETID_FORMAT, setup->vinfo.device.id, _die_x, _die_y);
   }
   else
   {                             // useID=False (die position)
      sprintf(str, "%d %d", _die_x , _die_y);
   }
   return 1;
}

/*------------------------------------------------
  Function :  ProberGetSubsitePosition
  Descript :  get subsite position    
  Input    :     
  Output   :  str : return string  
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ProberGetSubsitePosition(char *str)
{
   int  subsite = 0;

   ProberGetCurrSubsiteIndex(&subsite);
   _subsite_index = subsite;
   sprintf(str, "%d", _subsite_index);
   return 1;
}

/*------------------------------------------------
  Function :  _prober_output_enter_no_response
  Descript :  without get response 
  Input    :  command  
  Output   :  none
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
static int _prober_output_enter_no_response(const char *command)
{
   if (GpibOutput(command) != 1) {        // send command
      return 0;
   }
   return 1;
}

/*------------------------------------------------
  Function :  _prober_output_enter
  Descript :  get response after output command.  
  Input    :  command  
  Output   :  statusbyte  : statusbyte
              response    : message
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
static int _prober_output_enter(const char *command, int *statusbyte, char *response)
{
   char  buffer[PRB_COMMAND_MAXLEN];
   char  *p;
   char  *pos;
   char  buffer_temp[PRB_COMMAND_MAXLEN];

	int test = 0;
   
   *statusbyte = 0;                 // initial
   strcpy(response, "");               // initial


   if (GpibOutput(command) != 1) {        // send command
      return 0;
   }
   
   if (GpibEnter(buffer) != 1) return 0;  // get response

   strcpy(buffer_temp ,buffer);

   p = strtok(buffer_temp, MPI_SEPARATOR);  // result
   if (p != NULL) sscanf(p, "%d", &_statue_response); 


   if (_statue_response == 0)
   {
		strcpy(response, buffer);
	   return 1;    // no error
   }
   else if (_statue_response == 1024)
   {
		strcpy(response, buffer);
		*statusbyte = 1024;
	   return 1;    // no error -- Last die
   }   
   else if(_statue_response == 2048)
   {
	   strcpy(response, buffer);
	   *statusbyte = 2048;
	   return 1;    // no error -- Last subsite
   }
   else if(_statue_response == 11)
   {
	   *statusbyte = 11;	// no error -- Last die
	   return 1;			// no error -- End of Route
   }
   else
   {
	   return 1;    // error	
   }
}

/*------------------------------------------------
  Function :  _prober_parse_pos
  Descript :  The position of DIE 
              are acquired from a response string.
  Input    :  response
  Output   :  
  Return   :  
  ------------------------------------------------*/
static void _prober_parse_pos(char *response)
{
   char  *p;

	p = strtok(response, MPI_SEPARATOR);  // result
	p = strtok(NULL, MPI_SEPARATOR);  // id
   p = strtok(NULL, MPI_SEPARATOR);  // list_index(x)
   if (p != NULL) sscanf(p, "%d", &_list_index);  
   p = strtok(NULL, MPI_SEPARATOR);      // column(x)
   if (p != NULL) sscanf(p, "%d", &_die_x);
   p = strtok(NULL, MPI_SEPARATOR);      // row(y)
   if (p != NULL) sscanf(p, "%d", &_die_y);

   return;
}

/*------------------------------------------------
  Function :  _prober_wait_drive_complete
  Descript :  It waits to complete XY movement and Z movement.
  Input    :  
  Output   :  
  Return   :  1:Success/0:Fail(Error has Occurred)
  ------------------------------------------------*/
static int _prober_wait_drive_complete()
{
   char  command[PRB_COMMAND_MAXLEN];
   char  response[PRB_COMMAND_MAXLEN];
   int      stb;
   int      ismoving;
   char  *p;

   sprintf(command, "ReadChuckStatus");   // chuck status read.

   do {
      if (_prober_output_enter(command, &stb, response) != 1){ // send command
         return 0;
      }
      if (response[0] == '\0') return 1;
      p = strtok(response, SUSS_SEPARATOR);  // isInit
      if (p == NULL) return 1;            // skip
      p = strtok(NULL, SUSS_SEPARATOR);      // zMode
      if (p == NULL) return 1;            // skip
      p = strtok(NULL, SUSS_SEPARATOR);      // onEndLimit
      if (p == NULL) return 1;            // skip
      p = strtok(NULL, SUSS_SEPARATOR);      // isMoving
      if (p == NULL) return 1;            // skip
      strtrim(p);
      sscanf(p, "%d", &ismoving);
      if (ismoving != 0) Sleep(DRIVE_WAIT_MILLISEC);
   } while (ismoving != 0);

   return 1;
}

/*------------------------------------------------
  Function :  ProberGetWaferInfo
  Descript :  get wafer information
  Input    :  
  Output   :  
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ProberGetWaferInfo( variableinfo *vinfo)
{
   return 1;
}

/*------------------------------------------------
  Function :  ProberSubsiteStatus
  Descript :  get subsite is existing or not  
  Input    :  subsite number
  Output   :  0- inactive, 1-active   
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ProberGetSubsiteStatus(int *index, int *SubsiteStatus)
{
   char  command[PRB_COMMAND_MAXLEN];
   char  response[PRB_COMMAND_MAXLEN];
   int   stb;
   char  *p;
   *SubsiteStatus = 0;
   sprintf(command, "map:subsite:get_status %d",index);
   if (_prober_output_enter(command, &stb, response) != 1){
      return 1;
   }

   	p = strtok(response, MPI_SEPARATOR);			// result
	p = strtok(NULL, MPI_SEPARATOR);				// id
	p = strtok(NULL, MPI_SEPARATOR);				// list_index(x)
	if (p != NULL) sscanf(p, "%d", &_subsiteStatus);  
	*SubsiteStatus = _subsiteStatus;

    return 1;
}
