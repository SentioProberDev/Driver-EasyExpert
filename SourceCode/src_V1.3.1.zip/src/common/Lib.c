/* --------------------------------------------------------
   Library Function HeaderFile

   (c) Copyright Agilent Technologies 2005, 2008
   All rights reserved.


   Customer shall have the personal, non-
   transferable right to use, copy or modify
   this SAMPLE PROGRAM for Customer's internal
   operations.  Customer shall use the SAMPLE
   PROGRAM solely and exclusively for its own
   purpose and shall not license, lease, market
   or distribute the SAMPLE PROGRAM or modification
   or any part thereof.

   Agilent shall not be liable for the quality,
   performance or behavior of the SAMPLE PROGRAM.
   Agilent especially disclaims that the operation
   of the SAMPLE PROGRAM shall be uninterrupted or
   error free.  This SAMPLE PROGRAM is provided
   AS IS.

   AGILENT DISCLAIMS THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR
   PURPOSE.

   Agilent shall not be liable for any infringement
   of any patent, trademark copyright or other
   proprietary rights by the SAMPLE PROGRAM or
   its use. Agilent does not warrant that the SAMPLE
   PROGRAM is free from infringements or such
   right of third parties. However, Agilent will not
   knowingly infringe or deliver a software that
   infringes the patent, trademark, copyright or
   other proprietary right of a third party.

   Version     :  A.03.20

   ---------------------------------------------------------*/

#include "Lib.h"
#include <stdio.h>

#include <windows.h>
#include <shlwapi.h>
#include <shlobj.h>

#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "shell32.lib" )

static void GetSpecialDirectory( char* path, int nFolder );

/*------------------------------------------------
  Function :  getopt
  Descript :  command argument is analyzed.(like a unix base) 
  Input    :  command list   : argument string list  "-a -b AAA -c"
              optStirng      : option character.
              If a letter is followed by a colon, the option is expected to have an
              argument which may or may not be separated from it by white space.
  Output   :  optarg         : argument string 
  Return   :  option character
  ------------------------------------------------*/
char getopt(int argc, char * const argv[], const char *optString, char *optarg)
{
   static int  index = 1;
   static char *oldString = NULL;
   static char *oldArgv = NULL;
   char  *opt;
   int   len;
   int   i;

   // null check
   if (optarg!=NULL) strcpy(optarg, "");
   if (optString == NULL) return EOF;
   if (argc < 1) return EOF;

   // reset token
   if (oldString != NULL && oldString != optString)
      index = 1;
   if (oldArgv != NULL && oldArgv != argv[0])
      index = 1;
   oldString = (char *)optString;
   oldArgv = (char *)argv[0];

   if (index >= argc) return EOF;

   opt = argv[index++];       

   len = (int)strlen(optString);
   if (opt[0] == '-'){                      // option?
      for (i=0; i<len ; i++){                 // optString loop;
         if (opt[1] == optString[i]){
            if (optString[i+1] == ':'){       // expect have an argument?
               if (strlen(opt)>2) {       // argument with option
                  if (optarg!=NULL) strcpy(optarg, &opt[2]);
                  return opt[1];
               }
               else {                     // argument is next argv
                  if (index >= argc) return ':';
                  if (optarg!=NULL) strcpy(optarg, argv[index++]);
                  return opt[1];
               }
            } else {                     // only opt charcter.
               return opt[1];
            }
         }
      }
      return '?';
   } 
   return '?';
}

/*------------------------------------------------
  Function :  chomp
  Descript :  trim CR+LF  
  Input    :  string ( include last CRLF )  
  Output   :  string ( not inlcude last CRLF ) 
  Return   :  address of string 
  ------------------------------------------------*/
char  *chomp( char *string )
{
   int i;
   // null check
   if (string == NULL) return NULL;

   /* ----------------------------------------------
      strlen have bug.
      strlen("\n") : error occurred. 
   */
   if (string[0] == '\n'){
      if (string[1] == '\0') string[0] = '\0';
      return string;
   }
   // ----------------------------------------------

   if (strlen(string)<=1) return string;


   i = (int)strlen(string) - 1;
   while (string[i] == '\n' || string[i] == '\r'){ // search last character
      string[i]='\0';
      i--;
      if (i<0) break;
   }
   return string;
}

/*------------------------------------------------
  Function :  strtrim
  Descript :  deletion of an unnecessary space or TAB   
  Input    :  string ( include space(TAB) ) 
  Output   :  string ( not include space(TAB) )   
  Return   :  address of string 
  ------------------------------------------------*/
char *strtrim( char *string )
{
   int   start,end;
   int   e;

   // null check
   if (string == NULL) return string;
   if (string[0] == '\0') return string;

   // search start character.
   start=0;
   while ((string[start] == ' ' || string[start] == '\t') && start < (int)strlen(string))
      start++; // repeats until the first character is found.
   if (start > (int)strlen(string)) return string;

   // search end character.
   end = e = (int)strlen(string) - 1;
   while ((string[end] == ' ' || string[end] == '\t') && end > 0)
      end--;      // repeats until the last character is found.
   
   if (start == 0) {
      if (end == e)
         return string;
      string[end + 1] = '\0';
      return string;
   }

   strncpy(string, &string[start], end - start + 1);
   string[end - start + 1] = '\0';
   return string;
}

/* ------------------------------------------------------------
  Wrapper functions for Windows API
  ------------------------------------------------------------ */

int FileExists( const char *path )
{
   return ( PathFileExists( path ) == TRUE );
}

int FileCopy( const char *src, const char *dest )
{
   return ( CopyFile( src, dest, TRUE ) == TRUE );
}

int FileDelete( const char *target )
{
   return ( DeleteFile( target ) == TRUE );
}

int DirectoryCreate( const char *path )
{
   return ( SHCreateDirectoryEx( NULL, path, NULL ) == ERROR_SUCCESS );
}

void PathCompose( char *dest, const char *lpath, const char *rpath )
{
   char buf[MAX_PATH] = {'\0'};

   PathCombine( buf, lpath, rpath );
   strncpy( dest, buf, MAX_PATH );
}

int PathChangeExtension( char *path, const char *ext )
{
   return ( PathRenameExtension( path, ext ) == ERROR_SUCCESS );
}

void GetExecutableDirectory( char *path )
{
   char buf[MAX_PATH] = {'\0'};

   GetModuleFileName( NULL, buf, MAX_PATH );
   PathRemoveFileSpec( buf ); 
   strncpy( path, buf, MAX_PATH);
}

void GetCommonAppDataDirectory( char *path )
{
   char buf[MAX_PATH] = {'\0'};

   GetSpecialDirectory( buf, CSIDL_COMMON_APPDATA  );
   strncpy( path, buf, MAX_PATH);
}

void GetAppDataDirectory( char *path )
{
   char buf[MAX_PATH] = {'\0'};

   GetSpecialDirectory( buf, CSIDL_APPDATA );
   strncpy( path, buf, MAX_PATH);
}

static void GetSpecialDirectory( char *path, int nFolder )
{
   char buf[MAX_PATH] = {'\0'};

   SHGetSpecialFolderPath( NULL, buf, nFolder, FALSE );
   strncpy( path, buf, MAX_PATH);
}

