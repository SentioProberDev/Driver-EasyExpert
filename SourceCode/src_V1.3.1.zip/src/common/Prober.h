/* --------------------------------------------------------
   Prober Function HeaderFile

   (c) Copyright Agilent Technologies 2005, 2008
   All rights reserved.


   Customer shall have the personal, non-
   transferable right to use, copy or modify
   this SAMPLE PROGRAM for Customer's internal
   operations.  Customer shall use the SAMPLE
   PROGRAM solely and exclusively for its own
   purpose and shall not license, lease, market
   or distribute the SAMPLE PROGRAM or modification
   or any part thereof.

   Agilent shall not be liable for the quality,
   performance or behavior of the SAMPLE PROGRAM.
   Agilent especially disclaims that the operation
   of the SAMPLE PROGRAM shall be uninterrupted or
   error free.  This SAMPLE PROGRAM is provided
   AS IS.

   AGILENT DISCLAIMS THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR
   PURPOSE.

   Agilent shall not be liable for any infringement
   of any patent, trademark copyright or other
   proprietary rights by the SAMPLE PROGRAM or
   its use. Agilent does not warrant that the SAMPLE
   PROGRAM is free from infringements or such
   right of third parties. However, Agilent will not
   knowingly infringe or deliver a software that
   infringes the patent, trademark, copyright or
   other proprietary right of a third party.

   Version     :  A.03.20

   ---------------------------------------------------------*/

#ifndef _B1500_PRBDRV_PROBER_INCLUDE
#define _B1500_PRBDRV_PROBER_INCLUDE

#include "Utility.h"

#define  TARGET_MAXLEN        (1024)
#define  SUBSITE_MAXLEN       (1024)

// proto type
extern int ProberConnect( const proberinfo *pinfo);
extern int ProberDisConnect();
extern int ProberInitial();
extern int ProberStageUp();
extern int ProberStageDown();
extern int ProberMoveToNextDie(int *WaferEnd, int *WaferStop );
extern int ProberMoveToNextSubsite(int *DieEnd);
extern int ProberGetDiePosition(char *targt, const setupinfo *setup );
extern int ProberGetSubsitePosition(char *subsite);
extern int ProberGetTotalSubsiteCount(int *SubsiteCount);
extern int ProberGetCurrSubsiteIndex (int *SubsiteIndex);
extern int ProberGetWaferInfo( variableinfo *vinfo);
extern int ProberGetSubsiteStatus(int *index, int *SubsiteStatus);

#endif //_B1500_PRBDRV_PROBER_INCLUDE

