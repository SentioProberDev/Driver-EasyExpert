/* --------------------------------------------------------
   Library Function HeaderFile

   (c) Copyright Agilent Technologies 2005, 2008
   All rights reserved.


   Customer shall have the personal, non-
   transferable right to use, copy or modify
   this SAMPLE PROGRAM for Customer's internal
   operations.  Customer shall use the SAMPLE
   PROGRAM solely and exclusively for its own
   purpose and shall not license, lease, market
   or distribute the SAMPLE PROGRAM or modification
   or any part thereof.

   Agilent shall not be liable for the quality,
   performance or behavior of the SAMPLE PROGRAM.
   Agilent especially disclaims that the operation
   of the SAMPLE PROGRAM shall be uninterrupted or
   error free.  This SAMPLE PROGRAM is provided
   AS IS.

   AGILENT DISCLAIMS THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR
   PURPOSE.

   Agilent shall not be liable for any infringement
   of any patent, trademark copyright or other
   proprietary rights by the SAMPLE PROGRAM or
   its use. Agilent does not warrant that the SAMPLE
   PROGRAM is free from infringements or such
   right of third parties. However, Agilent will not
   knowingly infringe or deliver a software that
   infringes the patent, trademark, copyright or
   other proprietary right of a third party.

   Version     :  A.03.20

   ---------------------------------------------------------*/
#define  _UTILITY_GLOBAL_VALUE_DEFINE
#include "Utility.h"

#include "Lib.h"
#include <stdio.h>
#include <windows.h>

#define  INI_FILE          "prober_info.ini"
#define  WAFER_INI_FILE    "variable_info.ini"
#define  TEMPLATE_EXT      ".template"

#define  EasyEXPERT_CONFIG_DIR "Agilent\\EasyEXPERT"
#define  PROBER_CONFIG_DIR     "Agilent\\EasyEXPERT\\Utilities\\ProberControl"

#define  PRB_INFO_SECTION         "Prober"
#define  PRB_INFO_KEY_ADDRESS     "Address"
#define  PRB_INFO_KEY_LOGMODE     "LogMode"
#define  PRB_INFO_KEY_LOGNAME     "LogName"

#define  TGT_INFO_SECTION         "Target"
#define  TGT_INFO_KEY_USEID       "UseID"
#define  TGT_INFO_KEY_SUBSITEINFO "SubsiteInfo"
#define  TGT_INFO_KEY_WAFERINFO   "WaferInfo"

#define  DEV_INFO_SECTION          "Device"
#define  DEV_INFO_KEY_ID           "ID"

#define  WAF_INFO_SECTION         "WaferInfo"
#define  WAF_INFO_KEY_WAFERSIZE   "WaferSize"
#define  WAF_INFO_KEY_DIESTEPX    "DieStepX"
#define  WAF_INFO_KEY_DIESTEPY    "DieStepY"

#define  RESPONSE_CRLF     "\r\n"

#define  SWITCH_MAXLEN          (8)
#define  SWITCH_TRUE            "True"
#define  SWITCH_FALSE           "False"

#define  ERRMSG_MAXLEN        (1024)

// ProtoType
static int ParseIniProber( proberinfo *pinfo );
static int ParseIniVariable( variableinfo *vinfo );

static const char *GetIniFilePath( void );
static const char *GetVariableinfoIniFilePath( void );
static const char *GetRuntimeIniFilePath( void );

static void SecureCommonConfigDir( char *path );
static void SecureUserConfigDir( char *path );
static void GetTemplateDir( char *path );

static int  EasyEXPERTCommonConfigDirExists( void );




/*------------------------------------------------
  Function :  ParseOpt
  Descript :  parse command line.  
  Input    :  argc     : number of arugments
              argv     : list of arguments
  Output   :  pinfo : prober info
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ParseOpt(int argc, char *argv[], proberinfo *pinfo )
{
   char  optarg[MAX_PATH];
   char  c;
   int   result = 1;

   // NULL check
   if (pinfo == NULL){
      ShowErrorMessage("NULL pointer detected. resource\r\n");
      return 0;
   }

   // parse option
   while ((c = getopt(argc, argv, "a:l:", optarg)) != EOF){
      switch (c){
      case 'a':                     // designate GPIB address
         strncpy(pinfo->prober.address, optarg, ADDRESS_MAXLEN);
         break;
      case 'l':   // log mode on  
         pinfo->prober.log_mode = ON;
         strncpy(pinfo->prober.log_file_path, optarg, LOG_PATH_MAXLEN );
         break;
      case '?':                     // unknown option
         ShowErrorMessage("Error has occurred. Unknown option -%c\r\n", c);
         result = 0;
         break;
      default:
         result = 0;
         break;
      }
   }
   return result;
}

/*------------------------------------------------
  Function :  ParseIni
  Descript :  parse ini file.   
  Input    :     
  Output   :  setp : prober info and wafer info
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int ParseIni( setupinfo *setup )
{
   if ( ParseIniProber( &(setup->pinfo) ) != 1 )
   {
      return 0;
   }
   
   if( ParseIniVariable( &(setup->vinfo) ) != 1 )
   {
      return 0;
   }

   return 1;
}

/*------------------------------------------------
  Function :  WriteVariables
  Descript :  write variableinfo into ini file   
  Input    :  vinfo     
  Output   :  
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int WriteVariables( const variableinfo *vinfo )
{
   const char *inifile = GetVariableinfoIniFilePath();
   LPVOID lpMsgBuf;
   

   if ( WritePrivateProfileString(DEV_INFO_SECTION, DEV_INFO_KEY_ID, vinfo->device.id, inifile ) != TRUE )
   {
      FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
                    FORMAT_MESSAGE_IGNORE_INSERTS, NULL, GetLastError(), 
                    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR) &lpMsgBuf, 0, NULL);
      ShowErrorMessage("Error has occurred. WritePrivateProfileString: %s\r\n", (char *)lpMsgBuf);
      LocalFree( ( HLOCAL ) lpMsgBuf );
      return 0;
   }

   if ( WritePrivateProfileString(WAF_INFO_SECTION, WAF_INFO_KEY_WAFERSIZE, vinfo->wafer.wafer_size, inifile ) != TRUE
        || WritePrivateProfileString(WAF_INFO_SECTION, WAF_INFO_KEY_DIESTEPX, vinfo->wafer.die_size_x, inifile) != TRUE
        || WritePrivateProfileString(WAF_INFO_SECTION, WAF_INFO_KEY_DIESTEPY, vinfo->wafer.die_size_y, inifile) != TRUE )
   {
      FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
                    FORMAT_MESSAGE_IGNORE_INSERTS, NULL, GetLastError(), 
                    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR) &lpMsgBuf, 0, NULL);
      ShowErrorMessage("Error has occurred. WritePrivateProfileString: %s\r\n", (char *)lpMsgBuf);
      LocalFree( ( HLOCAL ) lpMsgBuf );
      return 0;
   }

   return 1;
}

/*------------------------------------------------
  Function :  WriteResponse
  Descript :  write response to stdout.  
  Input    :  breakflag   : continue flag "True"/"False"
              target      : Chip ID string.
              subsite     : Subsite ID string.
              setup       : 
  Output   :     
  Return   :  1:Success/0:Fail(Error has Occurred)
  ------------------------------------------------*/

#undef _DEBUG
//#define _DEBUG
int WriteResponse(const char *breakflag, const char *target, const char *subsite, 
                  const setupinfo *setup )
{
#ifdef _DEBUG
   char  buf[8];
#endif

   const proberinfo *pinfo = &( setup->pinfo );
   const variableinfo  *vinfo = &( setup->vinfo );

   fprintf(stdout, "<Response>%s",RESPONSE_CRLF);
   if ( breakflag != NULL ) 
   {
      fprintf(stdout, "  <Break>%s</Break>%s", breakflag, RESPONSE_CRLF);
   }

   if ( target != NULL && strlen(target) > 0 )
   {
      fprintf(stdout, "  <Target>%s%s%s", RESPONSE_CRLF, target, RESPONSE_CRLF);
   }
   
   if ( pinfo->condition.use_subsite_info == ON )
   {
      if ( subsite != NULL &&  strlen(subsite) > 0 )
      {
         fprintf(stdout, "    <Subsite>%s</Subsite>%s", subsite, RESPONSE_CRLF);
      }
   }
   
   if ( pinfo->condition.use_wafer_info == ON )
   {
      if ( strlen(vinfo->wafer.wafer_size ) > 0)
      {
         fprintf(stdout, "    <WaferSize>%s</WaferSize>%s", vinfo->wafer.wafer_size, RESPONSE_CRLF);
      }
      
      if ( strlen(vinfo->wafer.die_size_x ) > 0 && strlen(vinfo->wafer.die_size_y ) > 0)
      {
         fprintf(stdout, "    <DieSize>%s %s</DieSize>%s", 
                 vinfo->wafer.die_size_x, vinfo->wafer.die_size_y, RESPONSE_CRLF);
      }
   }
   
   if (target != NULL && strlen(target) > 0 )
   {
      fprintf(stdout, "  </Target>%s", RESPONSE_CRLF);
   }
   
   fprintf(stdout, "</Response>%s", RESPONSE_CRLF);
   fflush(stdout);

#ifdef _DEBUG
   fprintf(stderr, "push Enter key\n");
   fgets(buf, sizeof(buf), stdin);
#endif

   return 1;
}

/*------------------------------------------------
  Function :  ShowErrorMessage
  Descript :  Show Error Dialog 
  Input    :  printFmt : print Format
              ...         : argument
  Output   :     
  Return   :     
  ------------------------------------------------*/
void ShowErrorMessage(const char *printFmt, ... )
{
   char     message[ERRMSG_MAXLEN];
   va_list    va;

   if (printFmt == NULL) return;

   va_start(va, printFmt);
#ifndef _DEBUG
   vsprintf(message, printFmt, va);
   MessageBox(NULL, message, "Error", MB_ICONERROR | MB_OK | MB_APPLMODAL);
#else
   vsprintf(message, printFmt, va);
   fprintf(stderr, "%s\n", message);
#endif
   va_end(va);   

   return;
}

/* ------------------------------------------------------------
   static fuctions
   ------------------------------------------------------------ */

static int ParseIniProber( proberinfo *pinfo )
{
   const char *inifile = GetIniFilePath();
   FILE  *fp = NULL;
   char  switchbuf[ SWITCH_MAXLEN ] = {'\0'};
   
   // null check
   if ( pinfo == NULL){
      ShowErrorMessage("NULL pointer detected. resource\r\n");
      return 0;
   }

   pinfo->prober.address[0] ='\0';
   pinfo->prober.log_mode = OFF;
   pinfo->prober.log_file_path[0] ='\0';
   
   pinfo->condition.use_device_id    = OFF;
   pinfo->condition.use_subsite_info = OFF;
   pinfo->condition.use_wafer_info   = OFF;
   
   // check read permission
   if ((fp = fopen(inifile, "r"))==NULL)
   {
      perror(inifile);
      return 0;
   }
   fclose(fp);

   // [Prober] section
   //------------------------------------------------------------
   // GPIB address
   GetPrivateProfileString( PRB_INFO_SECTION, PRB_INFO_KEY_ADDRESS, 
                            "", pinfo->prober.address, ADDRESS_MAXLEN, inifile );
   // Log mode
   GetPrivateProfileString( PRB_INFO_SECTION, PRB_INFO_KEY_LOGMODE, 
                            SWITCH_FALSE, switchbuf, sizeof(switchbuf), inifile);

   if (_stricmp( switchbuf, SWITCH_TRUE) != 0 && _stricmp( switchbuf, SWITCH_FALSE) != 0)
   {
      ShowErrorMessage("%s is wrong. %s in %s\r\n", PRB_INFO_KEY_LOGMODE, switchbuf, inifile); 
   }
   pinfo->prober.log_mode = ( _stricmp( switchbuf, SWITCH_TRUE ) == 0 ? ON : OFF );

   // Log file
   GetPrivateProfileString( PRB_INFO_SECTION, PRB_INFO_KEY_LOGNAME, 
                            "", pinfo->prober.log_file_path, LOG_PATH_MAXLEN, inifile);
   
   // [Target] section
   //------------------------------------------------------------
   // use ID
   GetPrivateProfileString( TGT_INFO_SECTION, TGT_INFO_KEY_USEID, 
                            SWITCH_FALSE, switchbuf, sizeof(switchbuf), inifile);
   
   if (_stricmp( switchbuf, SWITCH_TRUE) != 0 && _stricmp( switchbuf, SWITCH_FALSE ) != 0)
   {
      ShowErrorMessage("%s is wrong. %s in %s\r\n", TGT_INFO_KEY_USEID, switchbuf, inifile); 
      return 0;   
   }
   pinfo->condition.use_device_id = ( _stricmp( switchbuf, SWITCH_TRUE ) == 0 ? ON : OFF );


   // SubsiteInfo
   GetPrivateProfileString(TGT_INFO_SECTION, TGT_INFO_KEY_SUBSITEINFO, 
                           SWITCH_FALSE, switchbuf, sizeof(switchbuf), inifile);

   if (_stricmp( switchbuf, SWITCH_TRUE ) != 0 && _stricmp( switchbuf, SWITCH_FALSE) != 0)
   {
      ShowErrorMessage("%s is wrong. %s in %s\r\n", TGT_INFO_KEY_SUBSITEINFO, switchbuf, inifile); 
      return 0;   
   }
   pinfo->condition.use_subsite_info = ( _stricmp( switchbuf, SWITCH_TRUE ) == 0 ? ON : OFF );
   

   // Variableinfo
   GetPrivateProfileString(TGT_INFO_SECTION, TGT_INFO_KEY_WAFERINFO, 
                           SWITCH_FALSE, switchbuf, sizeof(switchbuf), inifile);
   
   if (_stricmp( switchbuf, SWITCH_TRUE ) != 0 && _stricmp( switchbuf, SWITCH_FALSE) != 0)
   {
      ShowErrorMessage("%s is wrong. %s in %s\r\n", TGT_INFO_KEY_WAFERINFO, switchbuf, inifile);
      return 0;
   }
   pinfo->condition.use_wafer_info = ( _stricmp( switchbuf, SWITCH_TRUE ) == 0 ? ON : OFF );
   

   return 1;
}

static int ParseIniVariable( variableinfo *vinfo )
{
   const char *inifile = GetVariableinfoIniFilePath();
   FILE  *fp;

   // null check
   if (vinfo == NULL)
   {
      ShowErrorMessage("NULL pointer detected. vinfo\r\n");
      return 0;
   }

   vinfo->device.id[0] = '\0';
   
   vinfo->wafer.wafer_size[0] = '\0';
   vinfo->wafer.die_size_x[0] = '\0';
   vinfo->wafer.die_size_y[0] = '\0';

   // check read permission
   if ((fp = fopen(inifile, "r")) == NULL) 
   {
      return 1;
   }

   // [Device] section
   //------------------------------------------------------------
   // Device ID
   GetPrivateProfileString( DEV_INFO_SECTION, DEV_INFO_KEY_ID, 
                            "", vinfo->device.id, DEVICEID_MAXLEN, inifile);

   // [Wafer] setcion
   //------------------------------------------------------------
   // Wafer Size
   GetPrivateProfileString(WAF_INFO_SECTION, WAF_INFO_KEY_WAFERSIZE, 
                           "", vinfo->wafer.wafer_size, WAFER_SIZE_MAXLEN, inifile);

   // Die Step X
   GetPrivateProfileString(WAF_INFO_SECTION, WAF_INFO_KEY_DIESTEPX, 
                           "", vinfo->wafer.die_size_x, DIE_SIZE_MAXLEN, inifile);
   
   // Die Step Y
   GetPrivateProfileString(WAF_INFO_SECTION, WAF_INFO_KEY_DIESTEPY, 
                           "", vinfo->wafer.die_size_y, DIE_SIZE_MAXLEN, inifile);

   fclose( fp );
   
   return 1;
}

static const char *GetIniFilePath( void )
{
   static char path[MAX_PATH]       = {'\0'};

   char system[MAX_PATH]     = {'\0'}; /* for backward compatibility */
   char common[MAX_PATH]     = {'\0'}; /* A.03.20 or later */

   char skeleton[MAX_PATH]   = {'\0'}; // template for this INI file

   GetExecutableDirectory( system );
   PathCompose( system, system, INI_FILE );
   
   SecureCommonConfigDir( common );
   PathCompose( common, common, INI_FILE );

   GetTemplateDir( skeleton );
   PathCompose( skeleton, skeleton, INI_FILE );
   PathChangeExtension( skeleton, TEMPLATE_EXT );

   if ( FileExists( skeleton ) && ! FileExists( common ) )
   {
      FileCopy( skeleton, common );
   }

   if ( FileExists( system ) )
   {
      strncpy( path, system, MAX_PATH );
   }
   else
   {
      strncpy( path, common, MAX_PATH );
   }

   return ( const char *) path;
}

static const char *GetVariableinfoIniFilePath( void )
{
   static char path[MAX_PATH] = {'\0'};
   
   SecureCommonConfigDir( path );
   PathCompose( path, path, WAFER_INI_FILE );

   return ( const char *) path;
}

static void SecureCommonConfigDir( char *path )
{
   char buf[MAX_PATH] = {'\0'};
   
   GetCommonAppDataDirectory( buf );
   PathCompose( buf, buf, PROBER_CONFIG_DIR );

   if ( EasyEXPERTCommonConfigDirExists() )
   {
      DirectoryCreate( buf );
   }

   strncpy( path, buf, MAX_PATH );
}

static void GetTemplateDir( char *path )
{
   GetExecutableDirectory( path );
}

static int EasyEXPERTCommonConfigDirExists( void )
{
   char buf[MAX_PATH] = {'\0'};
   
   GetCommonAppDataDirectory( buf );
   PathCompose( buf, buf, EasyEXPERT_CONFIG_DIR );

   return FileExists( buf );
}
