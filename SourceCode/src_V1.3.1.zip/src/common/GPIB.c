/* --------------------------------------------------------
   Library Function HeaderFile

   (c) Copyright Agilent Technologies 2005, 2008
   All rights reserved.


   Customer shall have the personal, non-
   transferable right to use, copy or modify
   this SAMPLE PROGRAM for Customer's internal
   operations.  Customer shall use the SAMPLE
   PROGRAM solely and exclusively for its own
   purpose and shall not license, lease, market
   or distribute the SAMPLE PROGRAM or modification
   or any part thereof.

   Agilent shall not be liable for the quality,
   performance or behavior of the SAMPLE PROGRAM.
   Agilent especially disclaims that the operation
   of the SAMPLE PROGRAM shall be uninterrupted or
   error free.  This SAMPLE PROGRAM is provided
   AS IS.

   AGILENT DISCLAIMS THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR
   PURPOSE.

   Agilent shall not be liable for any infringement
   of any patent, trademark copyright or other
   proprietary rights by the SAMPLE PROGRAM or
   its use. Agilent does not warrant that the SAMPLE
   PROGRAM is free from infringements or such
   right of third parties. However, Agilent will not
   knowingly infringe or deliver a software that
   infringes the patent, trademark, copyright or
   other proprietary right of a third party.

   Version     :  A.03.20

   ---------------------------------------------------------*/

#include "GPIB.h"
#include "Lib.h"
#include "Utility.h"

#include <stdio.h>
#include <visa.h>
#include <time.h>
#include <string.h>
#include <windows.h>

#define  GPIB_LOGLEN          (512)
#define  GPIB_COMMAND_MAX_LEN (1024)

#define  GPIB_TIMEOUT         (60000)    // GPIB Timeout(msec)
#define  GPIB_TERMINATE       "\n"

#define  GPIB_ERROR_MSG             "GPIB Error has occurred."
#define  GPIB_ERROR_GPIB_OPEN_ERROR "GpibOpen must be finished previously."
#define  GPIB_ERROR_NULL_PTR_MSG    "NULL pointer detected"

#define  GPIB_RDLEN (64)

/*-------------------------------------------------------------------*
  If _GPIB_OFFLINE is defined, Enter and Stb input can be carried out 
  from standard input. 
  However, please be sure to perform as DebugMode (Console Application).
*/

//#define _GPIB_OFFLINE // GPIB Debug mode
#undef   _GPIB_OFFLINE  // GPIB normal mode

//-------------------------------------------------------------------*/


// private function(proto type)
static int _gpib_log_internal(const char *mode, const char *data);

// static(global variable)
static char _logfile[GPIB_LOGLEN];        
static enum GpibLogMode  _logmode = GPIB_LOG_OFF;
static int  _open_flag = 0;               // 1:Ready 0:Not Ready
static ViSession  _vi;
static ViSession  _viRM;

/*------------------------------------------------
  Function :  GpibOpen
  Descript :  Opens a VISA resource session given a VISA Resource Manager session. 
  Input    :  address ex)GPIB0::13::INSTR   
  Output   :     
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int GpibOpen(const char *address)
{
   char resource[GPIB_RDLEN];
   int         result;

   if (address == NULL){     // null check
      ShowErrorMessage("%s %s : visa resource\r\n", GPIB_ERROR_MSG, GPIB_ERROR_NULL_PTR_MSG);
      return 0;
   }

//   strncpy( resource, address, GPIB_RDLEN );			//Hoca
strncpy( resource, address, GPIB_RDLEN );


#ifdef _GPIB_OFFLINE
   fprintf(stderr, "GPIB resource : %s\n", resource);
   _open_flag = 1;
   return 1;
#endif

   // Open resource manager
   if ((result = viOpenDefaultRM (&_viRM)) != VI_SUCCESS){     
      ShowErrorMessage("%s Failed to open Resource Manager :%d(%X) \r\n", GPIB_ERROR_MSG, result, result);
      return 0;
   }
   // open session
   if ((result = viOpen(_viRM, resource, VI_NULL,VI_NULL, &_vi)) != VI_SUCCESS){
      ShowErrorMessage("%s Failed to open %s : %d(%X)\r\n", GPIB_ERROR_MSG, resource, result, result);
      return 0;
   }

   // set timeout(msec)
   if ((result = viSetAttribute(_vi, VI_ATTR_TMO_VALUE, GPIB_TIMEOUT)) != VI_SUCCESS){
      ShowErrorMessage("%s Failed to set attribute : %d(%X)\r\n", GPIB_ERROR_MSG, result, result);
      return 0;
   }

   _open_flag = 1;
   return 1;
}

/*------------------------------------------------
  Function :  GpibClose
  Descript :  Closes the specified resource manager session   
  Input    :     
  Output   :     
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int GpibClose()
{
   int         result;

#ifdef _GPIB_OFFLINE
   _open_flag = 0;
   return 1;
#endif
   // close session
   if ((result = viClose (_vi)) != VI_SUCCESS){ 
      ShowErrorMessage("%s Failed to close :%d(%X) \r\n", GPIB_ERROR_MSG, result, result);
      return 0;
   }
   // close resource manager
   if ((result = viClose (_viRM)) != VI_SUCCESS){
      ShowErrorMessage("%s Failed to close resource manager :%d(%X) \r\n", GPIB_ERROR_MSG, result, result);
      return 0;
   }
   _open_flag = 0;
   return 1;
}

/*------------------------------------------------
  Function :  GpibOutput
  Descript :  send command to device.    
  Input    :  cmd : command formats
  Output   :     
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int GpibOutput(const char *cmd )
{
   int         result;
   char     command[GPIB_COMMAND_MAX_LEN];

   // Check execute GpibOpen
   if (_open_flag != 1){         
      ShowErrorMessage("%s %s\r\n", GPIB_ERROR_MSG, GPIB_ERROR_GPIB_OPEN_ERROR);
      return 0;
   }

   // null check
   if (cmd == NULL){
      ShowErrorMessage("%s %s : command\r\n", GPIB_ERROR_MSG, GPIB_ERROR_NULL_PTR_MSG);
      return 0;
   }
   
   // logging
   if (! _gpib_log_internal("OUTPUT", cmd)) return 0;

   sprintf(command, "%s%s", cmd, GPIB_TERMINATE);

#ifndef _GPIB_OFFLINE
   if ((result = viPrintf(_vi, command)) != VI_SUCCESS){
      ShowErrorMessage("%s Failed to OUTPUT %s:%d(%X) \r\n", GPIB_ERROR_MSG, cmd, result, result);
      return 0;
   }
#else
   result = 1;
   fprintf(stderr, "OUTPUT : %s\n", cmd);
#endif

   return 1;
}
/*------------------------------------------------
  Function :  GpibEnter
  Descript :  enter string from device.  
  Input    :     
  Output   :  string   :  received data
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int GpibEnter(char *string)
{
   int result;

   // Check execute GpibOpen
   if (_open_flag != 1){         
      ShowErrorMessage("%s %s\r\n", GPIB_ERROR_MSG, GPIB_ERROR_GPIB_OPEN_ERROR);
      return 0;
   }

#ifndef _GPIB_OFFLINE
   if ((result = viScanf(_vi, "%t", string)) != VI_SUCCESS){
      ShowErrorMessage("%s Failed to ENTER :%d(%X) \r\n", GPIB_ERROR_MSG, result, result);
      return 0;
   }
#else
   result = 1;
   fprintf(stderr, "ENTER  : ");
   fgets(string, 512, stdin);
#endif

   //deletion of a line feed code and an unnecessary space
   chomp(strtrim(string));
   
   // logging
   if (! _gpib_log_internal("ENTER", string)) return 0;

   return 1;
}
/*------------------------------------------------
  Function :  GpibSrq
  Descript :  Read a status byte of the service request 
  Input    :     
  Output   :  statusByte  : status byte
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int GpibSrq(int *statusByte)
{
   int      result = 1;
   char  buf[32];
   ViUInt16  stb = 0;

   // Check execute GpibOpen
   if (_open_flag != 1){         
      ShowErrorMessage("%s %s\r\n", GPIB_ERROR_MSG, GPIB_ERROR_GPIB_OPEN_ERROR);
      return 0;
   }

#ifndef _GPIB_OFFLINE
   if ((result = viReadSTB(_vi, &stb)) != VI_SUCCESS){
      ShowErrorMessage("%s Failed to SRQ :%d(%X) \r\n", GPIB_ERROR_MSG, result, result);
      return 0;
   }
   *statusByte =  (int)stb;
#else
   fprintf(stderr, "SRQ    : ");
   fgets(buf, 512, stdin);
   sscanf(buf, "%d", statusByte);
#endif

   sprintf(buf, "%d", *statusByte); 
   if (! _gpib_log_internal("SRQ", buf)) return 0; // logging
   
   return 1;
}
/*------------------------------------------------
  Function :  GpibLogInit
  Descript :  Initialize log file  
  Input    :     
  Output   :     
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int GpibLogInit()
{
   FILE  *fp;
   if (_logmode==GPIB_LOG_OFF) return 1;    // Log Off
   if ((fp = fopen(_logfile, "w")) == NULL){
      perror(_logfile);
      return 0;
   }
   fclose(fp);
   return 1;
}


/*------------------------------------------------
  Function :  GpibSetLogMode
  Descript :  set logmode, logfilename   
  Input    :  logmode : enum GpibLogMode
              logfile : log filename (full path)
  Output   :     
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int GpibSetLog( const enum GpibLogMode mode, const char *logfile)
{
   char     logdir[GPIB_LOGLEN];
   char     *last, *p;
   DWORD    result;

   //------------------------------------ NULL check
   if (logfile == NULL){
      ShowErrorMessage("%s %s : logfile\r\n", GPIB_ERROR_MSG, GPIB_ERROR_NULL_PTR_MSG);
      return 0;
   }

   strcpy(_logfile, logfile);       // set logfile name

   //------------------------------------ set log mode
   _logmode = mode;

   /*----------------------------------------
     check log directory exists
     -----------------------------------------*/
   if (_logmode == GPIB_LOG_ON ){
      if (strcmp(_logfile, "")==0){
         ShowErrorMessage("logfile is not set.\r\n");
         return 0;
      }
      p = &_logfile[0];
      last = (char *)strrchr(p, '\\');
      if (last != NULL){
         strncpy(logdir, p,  (size_t)(last-p)); // get path name
         logdir[last-p] = '\0';     
         result = GetFileAttributes(logdir);    // get attribute (use WindowsAPI)
         if (result == 0xffffffff){
            ShowErrorMessage("%s %s is not exist. (%s)\r\n", GPIB_ERROR_MSG, logdir, logfile);
            return 0;
         }
      }
   }

   return 1;
}


/*------------------------------------------------
  Function :  _gpib_log_internal( private )
  Descript :  logging GPIB data to logfile  
  Input    :  mode OUTPUT/ENTER/SRQ
              data 
  Output   :  
  Return   :  1:Success/0:Fail(Error has Occurred)   
  ------------------------------------------------*/
int _gpib_log_internal(const char *mode, const char *data)
{
   FILE  *fp;
   char  strtime[32];
   struct   tm *timer;
   time_t   t;

   if (_logmode==GPIB_LOG_OFF) return 1;    // Log Off
   if ((fp = fopen(_logfile, "a")) == NULL){
      perror(_logfile);
      return 0;
   }

   // get time format
   time(&t);
   timer = localtime(&t);
   strftime(strtime, sizeof(strtime), "%m/%d/%Y %H:%M:%S", timer);
   fprintf(fp, "%s %7s : %s\n", strtime, mode, data);    // logging data

   fclose(fp);
   return 1;
}
