/* --------------------------------------------------------
   Library Function HeaderFile

   (c) Copyright Agilent Technologies 2005, 2008
   All rights reserved.


   Customer shall have the personal, non-
   transferable right to use, copy or modify
   this SAMPLE PROGRAM for Customer's internal
   operations.  Customer shall use the SAMPLE
   PROGRAM solely and exclusively for its own
   purpose and shall not license, lease, market
   or distribute the SAMPLE PROGRAM or modification
   or any part thereof.

   Agilent shall not be liable for the quality,
   performance or behavior of the SAMPLE PROGRAM.
   Agilent especially disclaims that the operation
   of the SAMPLE PROGRAM shall be uninterrupted or
   error free.  This SAMPLE PROGRAM is provided
   AS IS.

   AGILENT DISCLAIMS THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR
   PURPOSE.

   Agilent shall not be liable for any infringement
   of any patent, trademark copyright or other
   proprietary rights by the SAMPLE PROGRAM or
   its use. Agilent does not warrant that the SAMPLE
   PROGRAM is free from infringements or such
   right of third parties. However, Agilent will not
   knowingly infringe or deliver a software that
   infringes the patent, trademark, copyright or
   other proprietary right of a third party.

   Version     :  A.03.20

   ---------------------------------------------------------*/
#ifndef _B1500_PRBDRV_UTILITY_INCLUDE
#define _B1500_PRBDRV_UTILITY_INCLUDE

#define  RESPONSE_TRUE     "True"
#define  RESPONSE_FALSE    "False"

#define  ON                   (1)
#define  OFF                  (0)

#define  ADDRESS_MAXLEN       (64)
#define  LOG_PATH_MAXLEN      (256)

#define  DEVICEID_MAXLEN      (512)

#define  WAFER_SIZE_MAXLEN    (64)
#define  DIE_SIZE_MAXLEN      (64)

typedef struct
{
   struct 
   {
      char address[ADDRESS_MAXLEN];
      int  log_mode;
      char log_file_path[LOG_PATH_MAXLEN];
   } prober;

   struct 
   {
      int use_device_id;
      int use_subsite_info;
      int use_wafer_info;
   } condition;
} proberinfo;

typedef struct 
{
   struct 
   {
      char  id[DEVICEID_MAXLEN];
   } device;

   struct
   {
      char  wafer_size[WAFER_SIZE_MAXLEN];   // Wafer size string
      char  die_size_x[DIE_SIZE_MAXLEN];     // Die size(x) string
      char  die_size_y[DIE_SIZE_MAXLEN];     // Die size(y) string
   } wafer;
} variableinfo; 

typedef struct
{
   proberinfo    pinfo;
   variableinfo  vinfo;
} setupinfo;


extern int  ParseOpt( int argc, char *argv[], proberinfo *pinfo );
extern int  ParseIni( setupinfo *setup );
extern int  WriteVariables( const variableinfo *vinfo );
extern void ShowErrorMessage( const char *printFmt, ... );
extern int  WriteResponse( const char *breakflag, 
                           const char *target, 
                           const char *subsite, 
                           const setupinfo *setup );

#endif  // _B1500_PRBDRV_UTILITY_INCLUDE
